# BEST SMC PRO - GitHub Pages starter

1. Upload `index.html` to the root of the `best-smc-pro` repository.
2. Commit changes.
3. Open Settings -> Pages -> Deploy from a branch -> `main` -> `/(root)` -> Save.

Important: this is a static starter UI. Exact Exness XAGUSDc prices require a compatible secure data bridge. Signals are intentionally disabled until real candle data is connected and validated. The $10 page is a local journal only; it does not place trades. Never add broker passwords or secret API keys to this public repository.
